'''FUNCTION DEFINITION'''

#turn a song list into a string
def string_maker(filename):
    str='' #create a empty string
    file = open(filename, "r") #open the file in read mode
    str= file.read() # this will turn the file into a single strinb
    return str
    file.close()

#turn the string into a dictionary with key as the song and value as the style
def dictionary_maker(string):
    song_dictionary={} #empty dictionary
    song_list = string.split('\n') #split the string in a list of each line
    for song in song_list[:-1]: #iterate through the list to separates the style and the song
        song_list2 = song.split('-')  # - serepates song and style
        style = song_list2[1].split('/') # create a liste with subgenres
        for i in range(len(style)): # iterate through the subgenre to keek track of case and spaces
            style[i]= style[i].lower() # case
            style[i]=style[i].strip(' ') # spaces
        song_dictionary[song_list2[0]] = style # create the dictionary where the key is a liste of subgenres
    return song_dictionary

def song_selcter(dictionary):
    playlist_song = [] # create the liste that store of the songs
    while True: #loop until songs are selcted
        try: #Error Handling for unvalid input
            while playlist_song == []: #loop until the user_choice is valid
                print("Hi, I'm here to make you a Playlist\nSelect a muscic style from the list below:")
                user_choice = input("-Pop\n-Rock\n-Country\n-Hip Hop\n-Rap\n-Classical\n-Grunge\n-Reggae\n-Dance\n-Soul\n-R&B\n-Jazz\n-Blues\n-Alternative\n-Indie\n-Afropop\n-Kpop\n:" )
                user_choice = user_choice.lower() #account for case
                user_choice = user_choice.strip(' ') #spaces
                for song,style in dictionary.items():
                    if user_choice in style: # create a key/value pair with a liste of subgenres
                        playlist_song.append(song)
                if playlist_song == []: #Error Handling unvalid choices  of word.
                    print("Sorry, this style doesn't exist in our catalog:)")
            break
        except: #Error Handling for unvalid input
            print("Sorry that not a vaild style, try again:")
    return playlist_song

def write_playlistf(dict, outputname='playlist.txt'): #take in a dictionary and a file name
    playlistf = open(outputname,'w') #open the file to write in it
    for song in dict: # iterate through the dictionary to create the file
        playlistf.write(song+'\n') # create the formate
    playlistf.close() #close the file
    return playlistf


''' FUNCTION CALL '''

#call the string_maker function to turn string into a list
songs_string = string_maker("song.txt")
#call the sdictionary_maker function to turn the lis† unto a  dictioanr=y
songs_dictionary = dictionary_maker(songs_string)
#call the song_selcter function to turn the lis† unto a the selcted songs
playlist_dict =song_selcter(songs_dictionary)
#call the write_playlistf function to write the playlistinto a file
playlist_file = write_playlistf(playlist_dict)
print('Here is your playlist:')
print(' ')

for song in playlist_dict: # print each songs
    print(song)

print('You can also find a file attached with your playlist')
print('Thank you for using my sevrice')
